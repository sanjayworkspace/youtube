
require('dotenv').config();
const express = require('express');
const bodyParser = require('body-parser');
const cors = require('cors');
const { exec } = require('child_process');
const path = require('path');
const fs = require('fs');
const rateLimit = require('express-rate-limit');

const app = express();
const PORT = process.env.PORT || 3000;

// Middleware
app.use(cors());
app.use(bodyParser.json());

// Rate Limiting
const limiter = rateLimit({
    windowMs: 15 * 60 * 1000,
    max: 100,
});
app.use(limiter);

// Ensure the downloads directory exists
const downloadsDir = path.resolve(__dirname, 'downloads');
if (!fs.existsSync(downloadsDir)) {
    fs.mkdirSync(downloadsDir, { recursive: true });
}

// Serve static files (frontend directory)
app.use(express.static(path.join(__dirname, '../frontend')));

// Serve index.html for the root route
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, '../frontend/index.html'));
});

// Fetch available formats
app.post('/formats', async (req, res) => {
    const { url } = req.body;

    if (!url) {
        return res.status(400).send({ error: 'URL is required' });
    }

    console.log(`Received URL: ${url}`);

    if (!/^https?:\/\/(www\.)?(youtube\.com|youtu\.be)\/(watch\?v=|embed\/|v\/|shorts\/)?[a-zA-Z0-9_-]+/.test(url)) {
        return res.status(400).send({ error: 'Invalid YouTube URL' });
    }

    try {
        const metadataCommand = `yt-dlp --print-json ${url}`;
        const formatsCommand = `yt-dlp --list-formats --no-check-certificate ${url}`;

        const metadataOutput = await new Promise((resolve, reject) => {
            exec(metadataCommand, (error, stdout, stderr) => {
                if (error) reject(stderr);
                resolve(stdout);
            });
        });

        const metadata = JSON.parse(metadataOutput);
        const { title, thumbnail, duration_string } = metadata;

        const formatsOutput = await new Promise((resolve, reject) => {
            exec(formatsCommand, (error, stdout, stderr) => {
                if (error) reject(stderr);
                resolve(stdout);
            });
        });

        const allowedResolutions = ['144p', '240p', '360p', '480p', '720p', '1080p', '1440p', '2160p'];
        const formatsMap = {};

        formatsOutput.split('\n').slice(4).forEach(line => {
            const parts = line.trim().split(/\s+/);
            if (parts.length < 3) return;

            const formatCode = parts[0];
            const extension = parts[1];
            const resolution = parts[2];

            if (resolution.includes('x') === false || line.includes('audio') || line.includes('storyboard')) {
                return;
            }

            const normalizedResolution = resolution.match(/^\d+x\d+$/)
                ? `${parseInt(resolution.split('x')[1])}p`
                : resolution;

            if (allowedResolutions.includes(normalizedResolution)) {
                if (!formatsMap[normalizedResolution]) {
                    formatsMap[normalizedResolution] = { formatCode, resolution: normalizedResolution, extension };
                }
            }
        });

        const videoFormats = Object.values(formatsMap);

        if (videoFormats.length === 0) {
            return res.status(404).json({ error: 'No suitable video formats available for this video.' });
        }

        res.json({ videoFormats, title, thumbnail: thumbnail || metadata.thumbnails[0].url, duration: duration_string || 'Unknown' });
    } catch (error) {
        console.error(`Error: ${error}`);
        res.status(500).json({ error: 'Failed to fetch video formats or metadata' });
    }
});

// Download selected video
app.post('/download', async (req, res) => {
    const { url, videoFormat } = req.body;

    if (!url || !videoFormat) {
        return res.status(400).send({ error: 'URL and video format code are required' });
    }

    console.log(`Download request received. URL: ${url}, Format: ${videoFormat}`);

    const outputPath = path.resolve(downloadsDir, 'video_with_audio.mp4');
    const command = `yt-dlp -f ${videoFormat}+bestaudio --merge-output-format mp4 -o "${outputPath}" ${url}`;
    console.log(`Executing command: ${command}`);

    try {
        await new Promise((resolve, reject) => {
            exec(command, (error, stdout, stderr) => {
                if (error) reject(stderr);
                resolve(stdout);
            });
        });

        res.sendFile(outputPath, err => {
            if (err) {
                console.error(`File send error: ${err}`);
                res.status(500).send({ error: 'Failed to send file.' });
            } else {
                console.log('File sent successfully. Cleaning up...');
                fs.unlink(outputPath, unlinkErr => {
                    if (unlinkErr) {
                        console.error(`File cleanup error: ${unlinkErr}`);
                    }
                });
            }
        });
    } catch (error) {
        console.error(`Error: ${error}`);
        res.status(500).send({ error: 'Failed to download video' });
    }
});

// Start the server
app.listen(PORT, () => {
    console.log(`Server running on http://localhost:${PORT}`);
});
