
document.getElementById('downloadForm').addEventListener('submit', function (e) {
    e.preventDefault();

    const videoUrl = document.getElementById('videoUrl').value;
    const statusMessage = document.getElementById('statusMessage');
    const formatSelect = document.getElementById('formatSelect');

    if (!videoUrl) {
        statusMessage.textContent = 'Please enter a valid YouTube URL.';
        statusMessage.style.color = 'red';
        return;
    }

    statusMessage.textContent = 'Fetching formats...';
    statusMessage.style.color = 'blue';

    fetch('http://localhost:3000/formats', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ url: videoUrl })
    })
        .then(response => response.json())
        .then(data => {
            if (data.error) {
                throw new Error(data.error);
            }

            // Populate format dropdown
            formatSelect.innerHTML = data.formats.map(format => 
                `<option value="${format.formatCode}">${format.resolution} (${format.extension}) - ${format.note}</option>`
            ).join('');
            statusMessage.textContent = 'Formats loaded. Please select a quality.';
            statusMessage.style.color = 'green';
        })
        .catch(error => {
            console.error(error);
            statusMessage.textContent = 'Failed to fetch formats.';
            statusMessage.style.color = 'red';
        });
});

// Download the selected format
document.getElementById('downloadButton').addEventListener('click', function () {
    const videoUrl = document.getElementById('videoUrl').value;
    const formatCode = document.getElementById('formatSelect').value;
    const statusMessage = document.getElementById('statusMessage');

    if (!formatCode) {
        statusMessage.textContent = 'Please select a format.';
        statusMessage.style.color = 'red';
        return;
    }

    statusMessage.textContent = 'Downloading...';
    statusMessage.style.color = 'blue';

    fetch('http://localhost:3000/download', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ url: videoUrl, formatCode })
    })
        .then(response => {
            if (!response.ok) {
                throw new Error('Failed to download video');
            }
            return response.blob();
        })
        .then(blob => {
            const link = document.createElement('a');
            link.href = URL.createObjectURL(blob);
            link.download = 'video.mp4';
            link.click();
            statusMessage.textContent = 'Download complete!';
            statusMessage.style.color = 'green';
        })
        .catch(error => {
            console.error(error);
            statusMessage.textContent = 'Failed to download video.';
            statusMessage.style.color = 'red';
        });
});
